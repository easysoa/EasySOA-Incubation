package proto.bdaccess;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

import org.easysoa.registry.rest.integration.ServiceLevelHealth;
import org.easysoa.registry.rest.integration.SlaOrOlaIndicator;
import org.easysoa.registry.rest.integration.SlaOrOlaIndicators;

/**
 * A class that can connect to EasySOA core and export data. 
 * see: https://github.com/easysoa/EasySOA-Incubation/blob/master/easysoa-registry-v1/easysoa-registry-rest-server/src/test/java/org/easysoa/registry/integration/EndpointStateServiceTest.java
 */
public class ExportREST {
	
	// todo: not resolved
    private String endpointStateServiceUrl = this.getURL(EndpointStateServiceImpl.class);

    /**
     * endpointId : url of the service: the provider field of the json config file.
     * 
     * exp: "provider":"owsi-vm-easysoa-axxx-pivotal.accelance.net".
     */
    public final static String ENDPOINT_ID = "test";
    
    public final static String INDICATOR_NAME = "testSlaIndicator";
    
    
    
	/**
	 * Export data to EasySOA (REST).
	 * 
	 * 
	 */
	public Boolean exportData(Date dateFrom, Date dateTo, String endPointId, String slaOrOlaName, String level) throws Exception {
		
		Client client = createAuthenticatedHTTPClient();
	     	    	    
	    // Run update test request
        WebResource createUpdateRequest = client.resource(endpointStateServiceUrl).path("/slaOlaIndicators");
        
        SlaOrOlaIndicators slaOrOlaIndicatorsCreate = new SlaOrOlaIndicators();
        SlaOrOlaIndicator indicatorCreate = new SlaOrOlaIndicator();
        
        indicatorCreate.setEndpointId(endPointId);
        
        indicatorCreate.setSlaOrOlaName(slaOrOlaName);
        indicatorCreate.setServiceLevelViolation(true);
        
        ServiceLevelHealth srvLevelHealth=ServiceLevelHealth.bronze;
        
        if(level.equalsIgnoreCase("silver"))
        	srvLevelHealth=ServiceLevelHealth.silver;
        if(level.equalsIgnoreCase("gold"))
        	srvLevelHealth=ServiceLevelHealth.gold;
        if(level.equalsIgnoreCase("violation"))
        	srvLevelHealth=ServiceLevelHealth.violation;
        
        indicatorCreate.setServiceLevelHealth(srvLevelHealth);
        
        GregorianCalendar calendar = new GregorianCalendar(); // now
        indicatorCreate.setTimestamp(calendar.getTime());
        slaOrOlaIndicatorsCreate.getSlaOrOlaIndicatorList().add(indicatorCreate);
        createUpdateRequest.post(slaOrOlaIndicatorsCreate);
                        
		return true;			
	}
}
